#ifndef __FASTCLUSTER_WHETSTONE_HPP
#define __FASTCLUSTER_WHETSTONE_HPP

int
whetstone(double& flops, double& cpu_time, double min_cpu_time);

#endif
